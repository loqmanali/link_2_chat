import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:intl/intl.dart';

import '../../core/config/app_theme.dart';
import '../../core/models/phone_entry.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/loading_indicator.dart';
import 'history_viewmodel.dart';

class HistoryScreen extends HookWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final historyBloc = useMemoized(() => HistoryBloc(), []);

    // Load data when screen is first shown
    useEffect(() {
      historyBloc.add(LoadHistoryEvent());
      return () {
        historyBloc.close();
      };
    }, [historyBloc]);

    return BlocProvider(
      create: (context) => historyBloc,
      child: Scaffold(
        appBar: const CustomAppBar(title: 'History'),
        body: BlocBuilder<HistoryBloc, HistoryState>(
          builder: (context, state) {
            if (state.isLoading && state.entries.isEmpty) {
              return const LoadingIndicator(message: 'Loading history...');
            }

            if (state.entries.isEmpty) {
              return const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.history, size: 64, color: Colors.grey),
                    SizedBox(height: 16),
                    Text(
                      'No history yet',
                      style: TextStyle(fontSize: 18, color: Colors.grey),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Links you generate will appear here',
                      style: TextStyle(fontSize: 14, color: Colors.grey),
                    ),
                  ],
                ),
              );
            }

            return RefreshIndicator(
              onRefresh: () async {
                historyBloc.add(LoadHistoryEvent());
              },
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: state.entries.length,
                itemBuilder: (context, index) {
                  final entry = state.entries[index];
                  return _buildHistoryItem(context, entry, index);
                },
              ),
            );
          },
        ),
        floatingActionButton: BlocBuilder<HistoryBloc, HistoryState>(
          builder: (context, state) {
            if (state.entries.isEmpty) return const SizedBox();

            return FloatingActionButton(
              onPressed: () {
                _showClearHistoryDialog(context, historyBloc);
              },
              backgroundColor: Colors.red,
              child: const Icon(Icons.delete),
            );
          },
        ),
      ),
    );
  }

  Widget _buildHistoryItem(BuildContext context, PhoneEntry entry, int index) {
    final isWhatsApp = entry.platform == 'whatsapp';
    final platformColor =
        isWhatsApp ? AppTheme.whatsappColor : AppTheme.telegramColor;
    final dateFormat = DateFormat('MMM d, yyyy - h:mm a');

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: platformColor.withOpacity(0.2),
          child: Icon(
            isWhatsApp ? Icons.message : Icons.send,
            color: platformColor,
          ),
        ),
        title: Text(
          '${entry.countryCode} ${entry.phoneNumber}',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(entry.countryName),
            Text(
              dateFormat.format(entry.timestamp),
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
        trailing: Text(
          isWhatsApp ? 'WhatsApp' : 'Telegram',
          style: TextStyle(color: platformColor, fontWeight: FontWeight.bold),
        ),
        onTap: () {
          _showHistoryItemDetails(context, entry);
        },
      ),
    );
  }

  void _showHistoryItemDetails(BuildContext context, PhoneEntry entry) {
    final isWhatsApp = entry.platform == 'whatsapp';
    final platformName = isWhatsApp ? 'WhatsApp' : 'Telegram';
    final platformColor =
        isWhatsApp ? AppTheme.whatsappColor : AppTheme.telegramColor;
    final dateFormat = DateFormat('MMMM d, yyyy - h:mm a');

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Row(
              children: [
                Icon(
                  isWhatsApp ? Icons.message : Icons.send,
                  color: platformColor,
                ),
                const SizedBox(width: 8),
                Text('$platformName Link'),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Phone Number:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text('${entry.countryCode} ${entry.phoneNumber}'),
                const SizedBox(height: 8),
                const Text(
                  'Country:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(entry.countryName),
                const SizedBox(height: 8),
                const Text(
                  'Generated on:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(dateFormat.format(entry.timestamp)),
                const SizedBox(height: 8),
                const Text(
                  'Link:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(entry.link, style: const TextStyle(color: Colors.blue)),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Close'),
              ),
              TextButton(
                onPressed: () {
                  // Copy link
                  Navigator.of(context).pop();
                },
                child: const Text('Copy Link'),
              ),
              TextButton(
                onPressed: () {
                  // Open link
                  Navigator.of(context).pop();
                },
                child: const Text('Open Link'),
              ),
            ],
          ),
    );
  }

  void _showClearHistoryDialog(BuildContext context, HistoryBloc bloc) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Clear History'),
            content: const Text(
              'Are you sure you want to clear all history? This action cannot be undone.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () {
                  bloc.add(ClearHistoryEvent());
                  Navigator.of(context).pop();
                },
                style: TextButton.styleFrom(foregroundColor: Colors.red),
                child: const Text('Clear'),
              ),
            ],
          ),
    );
  }
}
