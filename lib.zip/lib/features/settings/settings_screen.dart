import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/config/app_theme.dart';
import '../../core/config/constants.dart';
import '../../core/models/user.dart';
import '../../core/services/auth_service.dart';
import '../../core/services/supabase_service.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/loading_indicator.dart';
import '../api/api_keys_screen.dart';
import '../auth/login_screen.dart';
import '../auth/register_screen.dart';
import '../subscription/subscription_screen.dart';

class SettingsScreen extends HookWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isLoading = useState(true);
    final themeMode = useState(ThemeMode.system);
    final saveLinksHistory = useState(true);
    final defaultPlatform = useState<String>('whatsapp');
    final showQrByDefault = useState(false);
    final currentUser = useState<User?>(null);

    // Load settings and user
    useEffect(() {
      _loadAll(
        themeMode: themeMode,
        saveLinksHistory: saveLinksHistory,
        defaultPlatform: defaultPlatform,
        showQrByDefault: showQrByDefault,
        currentUser: currentUser,
        setLoading: (val) => isLoading.value = val,
      );
      return null;
    }, []);

    // Show password dialog
    Future<String?> showPasswordDialog(BuildContext context) async {
      final passwordController = TextEditingController();

      return showDialog<String>(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text('Enter Password'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Please enter your password to continue'),
                  const SizedBox(height: 16),
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed:
                      () => Navigator.of(context).pop(passwordController.text),
                  child: const Text('Continue'),
                ),
              ],
            ),
      );
    }

    // Function to sync user data from Supabase
    Future<void> syncUserDataFromSupabase() async {
      try {
        // Show loading
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Syncing user data...'),
            duration: Duration(seconds: 1),
          ),
        );

        // Get the Supabase service
        final supabaseService = SupabaseService();

        // Check if Supabase is initialized
        if (!supabaseService.isInitialized) {
          await supabaseService.initialize();
        }

        // Get fresh user data from Supabase
        final supabaseUser = await supabaseService.getCurrentUser();

        if (supabaseUser == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Failed to sync: Not logged in to Supabase'),
              backgroundColor: Colors.red,
            ),
          );
          return;
        }

        // Get the current local user
        final authService = AuthService();
        final localUser = await authService.getCurrentUser();

        if (localUser == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Failed to sync: No local user found'),
              backgroundColor: Colors.red,
            ),
          );
          return;
        }

        // Update local user with Supabase data
        final updatedUser = localUser.copyWith(
          name: supabaseUser.name,
          role: supabaseUser.role,
          teamIds: supabaseUser.teamIds,
          subscriptionTier: supabaseUser.subscriptionTier,
          subscriptionExpiry: supabaseUser.subscriptionExpiry,
          lastLoginAt: supabaseUser.lastLoginAt,
          permissions: supabaseUser.permissions,
          preferences: supabaseUser.preferences,
          createdAt: supabaseUser.createdAt,
          passwordHash: supabaseUser.passwordHash,
        );

        // Save updated user
        await authService.updateUser(updatedUser);

        // Update UI
        currentUser.value = updatedUser;

        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('User data synced successfully'),
            backgroundColor: Colors.green,
          ),
        );

        // Restart the app to apply changes
        await Future.delayed(const Duration(seconds: 1));
        Navigator.pushReplacementNamed(context, '/main');
      } catch (e) {
        print('Error syncing user data: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error syncing data: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }

    // Function to force update all local data with Supabase
    Future<void> forceUpdateAllLocalData() async {
      try {
        // Show loading
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Updating all local data...'),
            duration: Duration(seconds: 2),
          ),
        );

        // Get the Supabase service
        final supabaseService = SupabaseService();

        // Check if Supabase is initialized
        if (!supabaseService.isInitialized) {
          await supabaseService.initialize();
        }

        // Get the current local user
        final authService = AuthService();
        final localUser = await authService.getCurrentUser();

        if (localUser == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Failed: No local user found'),
              backgroundColor: Colors.red,
            ),
          );
          return;
        }

        // Try to login again to refresh the session
        final email = localUser.email;

        // Show password dialog
        final password = await showPasswordDialog(context);

        if (password == null || password.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Cancelled by user'),
              backgroundColor: Colors.orange,
            ),
          );
          return;
        }

        // Login with Supabase
        final updatedUser = await authService.loginWithSupabase(
          email,
          password,
        );

        if (updatedUser == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Failed to login with Supabase'),
              backgroundColor: Colors.red,
            ),
          );
          return;
        }

        // Update UI
        currentUser.value = updatedUser;

        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('All data updated successfully'),
            backgroundColor: Colors.green,
          ),
        );

        // Restart the app to apply changes
        await Future.delayed(const Duration(seconds: 1));
        Navigator.pushReplacementNamed(context, '/main');
      } catch (e) {
        print('Error updating all local data: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    }

    return Scaffold(
      appBar: const CustomAppBar(title: 'Settings'),
      body:
          isLoading.value
              ? const LoadingIndicator(message: 'Loading settings...')
              : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (currentUser.value != null) ...[
                    _buildProfileSection(context, currentUser.value!),
                    const Divider(),
                  ] else ...[
                    _buildGuestLoginSection(context),
                    const Divider(),
                  ],

                  _buildSectionHeader('Appearance'),
                  _buildThemeSelector(themeMode.value, (value) {
                    themeMode.value = value;
                    _saveThemeMode(value);
                  }),
                  const Divider(),

                  _buildSectionHeader('Behavior'),
                  _buildSwitchTile(
                    title: 'Save links history',
                    subtitle: 'Keep a record of all generated links',
                    value: saveLinksHistory.value,
                    onChanged: (value) {
                      saveLinksHistory.value = value;
                      _saveBoolSetting('save_links_history', value);
                    },
                  ),
                  _buildSwitchTile(
                    title: 'Show QR code by default',
                    subtitle: 'Display QR code when link is generated',
                    value: showQrByDefault.value,
                    onChanged: (value) {
                      showQrByDefault.value = value;
                      _saveBoolSetting('show_qr_by_default', value);
                    },
                  ),
                  _buildPlatformSelector(defaultPlatform.value, (value) {
                    defaultPlatform.value = value;
                    _saveStringSetting('default_platform', value);
                  }),
                  const Divider(),

                  _buildSectionHeader('About'),
                  ListTile(
                    title: const Text('Version'),
                    subtitle: const Text(AppConstants.appVersion),
                    leading: const Icon(Icons.info_outline),
                  ),
                  ListTile(
                    title: const Text('Privacy Policy'),
                    subtitle: const Text('Read our privacy policy'),
                    leading: const Icon(Icons.privacy_tip_outlined),
                    onTap: () => _showComingSoonMessage(context),
                  ),
                  ListTile(
                    title: const Text('Terms of Service'),
                    subtitle: const Text('Read our terms of service'),
                    leading: const Icon(Icons.gavel_outlined),
                    onTap: () => _showComingSoonMessage(context),
                  ),

                  if (currentUser.value != null) ...[
                    const Divider(),
                    _buildSectionHeader('Subscription'),
                    _buildSubscriptionTile(context, currentUser.value!),

                    if (currentUser.value!.subscriptionTier.hasApiAccess)
                      ListTile(
                        title: const Text('API Keys'),
                        subtitle: const Text('Manage API keys for integration'),
                        leading: const Icon(Icons.vpn_key),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const ApiKeysScreen(),
                            ),
                          );
                        },
                      ),

                    // Add sync users option for admin users
                    if (currentUser.value!.role == 'admin')
                      ListTile(
                        title: const Text('Sync Local Users'),
                        subtitle: const Text('Sync local users with Supabase'),
                        leading: const Icon(Icons.sync),
                        onTap: () => _showSyncUsersDialog(context),
                      ),

                    ListTile(
                      title: const Text('Sync Account Data'),
                      subtitle: const Text(
                        'Refresh subscription and teams data',
                      ),
                      leading: const Icon(Icons.sync),
                      onTap: syncUserDataFromSupabase,
                    ),

                    ListTile(
                      title: const Text('Force Update All Data'),
                      subtitle: const Text(
                        'Re-login and update all local data',
                      ),
                      leading: const Icon(Icons.update),
                      onTap: forceUpdateAllLocalData,
                    ),

                    const Divider(),
                    ListTile(
                      title: const Text(
                        'Sign Out',
                        style: TextStyle(color: Colors.red),
                      ),
                      leading: const Icon(Icons.logout, color: Colors.red),
                      onTap: () => _logout(context),
                    ),
                  ],
                ],
              ),
    );
  }

  Widget _buildProfileSection(BuildContext context, User user) {
    final dateFormat =
        '${user.lastLoginAt.year}-${user.lastLoginAt.month.toString().padLeft(2, '0')}-${user.lastLoginAt.day.toString().padLeft(2, '0')}';

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Profile'),
            const SizedBox(height: 8),
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: AppTheme.primaryColor.withOpacity(0.2),
                  child: Text(
                    user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user.name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        user.email,
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: _getRoleColor(user.role),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              _getRoleDisplayName(user.role),
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Last login: $dateFormat',
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildRolePermissions(user),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () => _showEditProfileDialog(context, user),
              icon: const Icon(Icons.edit),
              label: const Text('Edit Profile'),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: () => _showDeleteAccountDialog(context, user),
              icon: const Icon(Icons.delete_forever, color: Colors.red),
              label: const Text(
                'Delete Account',
                style: TextStyle(color: Colors.red),
              ),
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: 12,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRolePermissions(User user) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Permissions',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            _buildPermissionChip('Create Links', true),
            _buildPermissionChip('View History', true),
            _buildPermissionChip(
              'Create Teams',
              user.role == 'admin' ||
                  user.subscriptionTier != SubscriptionTier.free,
            ),
            _buildPermissionChip(
              'API Access',
              user.subscriptionTier.hasApiAccess,
            ),
            _buildPermissionChip(
              'Advanced Analytics',
              user.subscriptionTier.hasAdvancedAnalytics,
            ),
            if (user.role == 'admin') _buildPermissionChip('Admin Panel', true),
          ],
        ),
      ],
    );
  }

  Widget _buildPermissionChip(String label, bool enabled) {
    return Chip(
      label: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          color: enabled ? Colors.black87 : Colors.grey,
        ),
      ),
      backgroundColor: enabled ? Colors.green.shade50 : Colors.grey.shade100,
      side: BorderSide(
        color: enabled ? Colors.green.shade200 : Colors.grey.shade300,
      ),
      avatar: Icon(
        enabled ? Icons.check_circle : Icons.cancel,
        size: 16,
        color: enabled ? Colors.green : Colors.grey,
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'admin':
        return Colors.purple;
      case 'manager':
        return Colors.blue;
      case 'member':
        return Colors.green;
      case 'viewer':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  String _getRoleDisplayName(String role) {
    // Capitalize first letter
    return role.isNotEmpty
        ? role[0].toUpperCase() + role.substring(1)
        : 'Member';
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: AppTheme.primaryColor,
        ),
      ),
    );
  }

  Widget _buildThemeSelector(
    ThemeMode currentMode,
    Function(ThemeMode) onChanged,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Theme Mode',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                _buildThemeChip(
                  'System',
                  ThemeMode.system,
                  currentMode,
                  onChanged,
                  Icons.smartphone,
                ),
                _buildThemeChip(
                  'Light',
                  ThemeMode.light,
                  currentMode,
                  onChanged,
                  Icons.light_mode,
                ),
                _buildThemeChip(
                  'Dark',
                  ThemeMode.dark,
                  currentMode,
                  onChanged,
                  Icons.dark_mode,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildThemeChip(
    String label,
    ThemeMode mode,
    ThemeMode currentMode,
    Function(ThemeMode) onChanged,
    IconData icon,
  ) {
    final isSelected = currentMode == mode;
    return ChoiceChip(
      label: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: isSelected ? Colors.white : Colors.grey),
          const SizedBox(width: 4),
          Text(label),
        ],
      ),
      selected: isSelected,
      onSelected: (selected) {
        if (selected) {
          onChanged(mode);
        }
      },
      selectedColor: AppTheme.primaryColor,
      labelStyle: TextStyle(color: isSelected ? Colors.white : Colors.black),
    );
  }

  Widget _buildSwitchTile({
    required String title,
    required String subtitle,
    required bool value,
    required Function(bool) onChanged,
  }) {
    return SwitchListTile(
      title: Text(title),
      subtitle: Text(subtitle),
      value: value,
      onChanged: onChanged,
      activeColor: AppTheme.primaryColor,
    );
  }

  Widget _buildPlatformSelector(
    String currentPlatform,
    Function(String) onChanged,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Default Platform',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                _buildPlatformChip(
                  'WhatsApp',
                  'whatsapp',
                  currentPlatform,
                  onChanged,
                  AppTheme.whatsappColor,
                ),
                _buildPlatformChip(
                  'Telegram',
                  'telegram',
                  currentPlatform,
                  onChanged,
                  AppTheme.telegramColor,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlatformChip(
    String label,
    String platform,
    String currentPlatform,
    Function(String) onChanged,
    Color platformColor,
  ) {
    final isSelected = currentPlatform == platform;
    return ChoiceChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (selected) {
        if (selected) {
          onChanged(platform);
        }
      },
      selectedColor: platformColor,
      labelStyle: TextStyle(color: isSelected ? Colors.white : Colors.black),
    );
  }

  void _showComingSoonMessage(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('This feature is coming soon!'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _showEditProfileDialog(BuildContext context, User user) async {
    final nameController = TextEditingController(text: user.name);
    final emailController = TextEditingController(text: user.email);
    final passwordController = TextEditingController();
    final formKey = GlobalKey<FormState>();

    String? errorMessage;
    bool isLoading = false;

    await showDialog(
      context: context,
      builder:
          (dialogContext) => StatefulBuilder(
            builder:
                (context, setState) => AlertDialog(
                  title: const Text('Edit Profile'),
                  content: Form(
                    key: formKey,
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (errorMessage != null)
                            Container(
                              padding: const EdgeInsets.all(8),
                              margin: const EdgeInsets.only(bottom: 16),
                              decoration: BoxDecoration(
                                color: Colors.red.shade50,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                errorMessage ?? '',
                                style: const TextStyle(color: Colors.red),
                              ),
                            ),
                          TextFormField(
                            controller: nameController,
                            decoration: const InputDecoration(
                              labelText: 'Name',
                              prefixIcon: Icon(Icons.person_outline),
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your name';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 16),
                          TextFormField(
                            controller: emailController,
                            decoration: const InputDecoration(
                              labelText: 'Email',
                              prefixIcon: Icon(Icons.email_outlined),
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your email';
                              }
                              if (!RegExp(
                                r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$',
                              ).hasMatch(value)) {
                                return 'Please enter a valid email';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 16),
                          TextFormField(
                            controller: passwordController,
                            decoration: const InputDecoration(
                              labelText:
                                  'New Password (leave blank to keep current)',
                              prefixIcon: Icon(Icons.lock_outline),
                            ),
                            obscureText: true,
                            validator: (value) {
                              if (value != null &&
                                  value.isNotEmpty &&
                                  value.length < 6) {
                                return 'Password must be at least 6 characters';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 16),
                        ],
                      ),
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.of(dialogContext).pop(),
                      child: const Text('Cancel'),
                    ),
                    if (isLoading)
                      const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    else
                      TextButton(
                        onPressed: () async {
                          if (formKey.currentState!.validate()) {
                            setState(() {
                              isLoading = true;
                              errorMessage = null;
                            });

                            final result = await AuthService().updateProfile(
                              user.id,
                              name: nameController.text,
                              email: emailController.text,
                              newPassword:
                                  passwordController.text.isEmpty
                                      ? null
                                      : passwordController.text,
                            );

                            setState(() {
                              isLoading = false;
                            });

                            if (result == null) {
                              setState(() {
                                errorMessage =
                                    'Update failed. Email may already be in use.';
                              });
                            } else {
                              if (dialogContext.mounted) {
                                Navigator.of(dialogContext).pop(true);
                              }
                            }
                          }
                        },
                        child: const Text('Save'),
                      ),
                  ],
                ),
          ),
    ).then((updated) {
      if (updated == true) {
        // Refresh the page
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Profile updated successfully'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    });
  }

  Future<void> _logout(BuildContext context) async {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Sign Out'),
            content: const Text('Are you sure you want to sign out?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () async {
                  Navigator.of(context).pop();

                  // Show loading
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Signing out...'),
                      duration: Duration(seconds: 1),
                    ),
                  );

                  // Perform complete logout
                  await AuthService().logout();

                  // Clear any cached preferences
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.remove('theme_mode');
                  await prefs.remove('save_links_history');
                  await prefs.remove('default_platform');
                  await prefs.remove('show_qr_by_default');

                  // Navigate to login screen with a slight delay to ensure all resources are properly disposed
                  if (context.mounted) {
                    // Use Future.delayed to ensure all resources are properly disposed before navigation
                    Future.delayed(const Duration(milliseconds: 100), () {
                      if (context.mounted) {
                        Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(
                            builder: (_) => const LoginScreen(),
                          ),
                          (route) => false,
                        );
                      }
                    });
                  }
                },
                child: const Text('Sign Out'),
              ),
            ],
          ),
    );
  }

  Widget _buildSubscriptionTile(BuildContext context, User user) {
    final tier = user.subscriptionTier;
    final isActive = user.hasActiveSubscription;
    String tierName;

    switch (tier) {
      case SubscriptionTier.free:
        tierName = 'Free';
        break;
      case SubscriptionTier.basic:
        tierName = 'Basic';
        break;
      case SubscriptionTier.professional:
        tierName = 'Professional';
        break;
      case SubscriptionTier.enterprise:
        tierName = 'Enterprise';
        break;
    }

    // Check if user has premium subscription but no teams
    final bool isPremiumWithNoTeams =
        tier != SubscriptionTier.free && isActive && (user.teamIds.isEmpty);

    return Column(
      children: [
        ListTile(
          title: const Text('Subscription Plan'),
          subtitle: Text(
            tier == SubscriptionTier.free
                ? 'Current Plan: $tierName'
                : isActive
                ? 'Current Plan: $tierName (Active)'
                : 'Current Plan: $tierName (Expired)',
          ),
          leading: const Icon(Icons.card_membership),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const SubscriptionScreen(),
              ),
            );
          },
        ),

        // Show create team button for premium users with no teams
        if (isPremiumWithNoTeams)
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 8.0,
            ),
            child: Card(
              color: Colors.blue.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.info_outline, color: Colors.blue),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'You have a premium subscription but haven\'t created any teams yet',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Teams allow you to collaborate with others and share links',
                      style: TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Navigator.pushNamed(context, '/teams');
                        },
                        icon: const Icon(Icons.group_add),
                        label: const Text('Create Your First Team'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }

  Future<void> _showSyncUsersDialog(BuildContext context) async {
    final emailController = TextEditingController();
    final passwordController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    bool isLoading = false;

    return showDialog(
      context: context,
      builder:
          (dialogContext) => StatefulBuilder(
            builder:
                (context, setState) => AlertDialog(
                  title: const Text('Sync Users with Supabase'),
                  content: Form(
                    key: formKey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          'Enter admin credentials to sync local users with Supabase. '
                          'This will create accounts for all local users.',
                          style: TextStyle(fontSize: 14),
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: emailController,
                          decoration: const InputDecoration(
                            labelText: 'Admin Email',
                            prefixIcon: Icon(Icons.email_outlined),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter admin email';
                            }
                            return null;
                          },
                        ),
                        const SizedBox(height: 8),
                        TextFormField(
                          controller: passwordController,
                          decoration: const InputDecoration(
                            labelText: 'Admin Password',
                            prefixIcon: Icon(Icons.lock_outline),
                          ),
                          obscureText: true,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter admin password';
                            }
                            return null;
                          },
                        ),
                      ],
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(dialogContext),
                      child: const Text('Cancel'),
                    ),
                    if (isLoading)
                      const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    else
                      ElevatedButton(
                        onPressed: () async {
                          if (formKey.currentState!.validate()) {
                            setState(() {
                              isLoading = true;
                            });

                            try {
                              final results = await AuthService()
                                  .syncLocalUsersWithSupabase(
                                    adminEmail: emailController.text,
                                    adminPassword: passwordController.text,
                                  );

                              setState(() {
                                isLoading = false;
                              });

                              if (dialogContext.mounted) {
                                Navigator.pop(dialogContext);
                                _showSyncResultsDialog(context, results);
                              }
                            } catch (e) {
                              setState(() {
                                isLoading = false;
                              });

                              if (dialogContext.mounted) {
                                ScaffoldMessenger.of(
                                  dialogContext,
                                ).showSnackBar(
                                  SnackBar(
                                    content: Text('Error: ${e.toString()}'),
                                    backgroundColor: Colors.red,
                                  ),
                                );
                              }
                            }
                          }
                        },
                        child: const Text('Sync Users'),
                      ),
                  ],
                ),
          ),
    );
  }

  void _showSyncResultsDialog(
    BuildContext context,
    Map<String, dynamic> results,
  ) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Sync Results'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Total users: ${results['total']}'),
                  Text('Successfully synced: ${results['success']}'),
                  Text('Failed: ${results['failed']}'),
                  Text('Skipped: ${results['skipped']}'),
                  if (results.containsKey('error'))
                    Text(
                      'Error: ${results['error']}',
                      style: const TextStyle(color: Colors.red),
                    ),
                  const SizedBox(height: 16),
                  if ((results['details'] as List).isNotEmpty) ...[
                    const Text(
                      'Details:',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    ...((results['details'] as List).map(
                      (detail) => Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: _getSyncStatusColor(detail['status']),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Email: ${detail['email']}'),
                            Text('Status: ${detail['status']}'),
                            if (detail.containsKey('reason'))
                              Text('Reason: ${detail['reason']}'),
                            if (detail.containsKey('newId'))
                              Text('New ID: ${detail['newId']}'),
                          ],
                        ),
                      ),
                    )),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
            ],
          ),
    );
  }

  Color _getSyncStatusColor(String status) {
    switch (status) {
      case 'success':
        return Colors.green.shade50;
      case 'failed':
        return Colors.red.shade50;
      case 'skipped':
        return Colors.yellow.shade50;
      case 'error':
        return Colors.orange.shade50;
      default:
        return Colors.grey.shade50;
    }
  }

  // Show dialog to confirm account deletion
  void _showDeleteAccountDialog(BuildContext context, User user) {
    final passwordController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    bool isLoading = false;

    showDialog(
      context: context,
      builder:
          (dialogContext) => StatefulBuilder(
            builder:
                (context, setState) => AlertDialog(
                  title: const Text('Delete Account'),
                  content: SingleChildScrollView(
                    child: Form(
                      key: formKey,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text(
                            'Warning: This action cannot be undone. All your data will be permanently deleted.',
                            style: TextStyle(color: Colors.red),
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'Please enter your password to confirm deletion:',
                          ),
                          const SizedBox(height: 8),
                          TextFormField(
                            controller: passwordController,
                            decoration: const InputDecoration(
                              labelText: 'Password',
                              prefixIcon: Icon(Icons.lock_outline),
                            ),
                            obscureText: true,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your password';
                              }
                              return null;
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(dialogContext),
                      child: const Text('Cancel'),
                    ),
                    if (isLoading)
                      const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    else
                      ElevatedButton(
                        onPressed: () async {
                          if (formKey.currentState!.validate()) {
                            setState(() {
                              isLoading = true;
                            });

                            try {
                              final success = await AuthService().deleteAccount(
                                user.id,
                                password: passwordController.text,
                              );

                              if (success) {
                                // Close the dialog
                                if (dialogContext.mounted) {
                                  Navigator.pop(dialogContext);
                                }

                                // Navigate to login screen
                                if (context.mounted) {
                                  Navigator.pushAndRemoveUntil(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => const LoginScreen(),
                                    ),
                                    (route) => false,
                                  );

                                  // Show success message
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        'Account deleted successfully',
                                      ),
                                      backgroundColor: Colors.green,
                                    ),
                                  );
                                }
                              } else {
                                setState(() {
                                  isLoading = false;
                                });

                                if (dialogContext.mounted) {
                                  ScaffoldMessenger.of(
                                    dialogContext,
                                  ).showSnackBar(
                                    const SnackBar(
                                      content: Text('Incorrect password'),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                }
                              }
                            } catch (e) {
                              setState(() {
                                isLoading = false;
                              });

                              if (dialogContext.mounted) {
                                ScaffoldMessenger.of(
                                  dialogContext,
                                ).showSnackBar(
                                  SnackBar(
                                    content: Text('Error: ${e.toString()}'),
                                    backgroundColor: Colors.red,
                                  ),
                                );
                              }
                            }
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                        ),
                        child: const Text('Delete Account'),
                      ),
                  ],
                ),
          ),
    );
  }

  // Add new method to build guest login section
  Widget _buildGuestLoginSection(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Account'),
            const SizedBox(height: 8),
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.grey.withOpacity(0.2),
                  child: const Icon(
                    Icons.person_outline,
                    size: 30,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Guest User',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Text(
                        'You are currently using the app as a guest',
                        style: TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.orange.shade100,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Text(
                          'Limited Features',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.deepOrange,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text(
              'Sign in or create an account to access all features:',
              style: TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 8),
            _buildFeatureList(),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _navigateToLogin(context),
                    icon: const Icon(Icons.login),
                    label: const Text('Sign In'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _navigateToRegister(context),
                    icon: const Icon(Icons.person_add),
                    label: const Text('Sign Up'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeatureList() {
    return Column(
      children: [
        _buildFeatureItem('Save your link history'),
        _buildFeatureItem('Sync across devices'),
        _buildFeatureItem('Create teams and share links'),
        _buildFeatureItem('Access advanced analytics'),
        _buildFeatureItem('Use API for integrations'),
      ],
    );
  }

  Widget _buildFeatureItem(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          const Icon(
            Icons.check_circle,
            color: AppTheme.primaryColor,
            size: 16,
          ),
          const SizedBox(width: 8),
          Text(text),
        ],
      ),
    );
  }

  void _navigateToLogin(BuildContext context) {
    Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  void _navigateToRegister(BuildContext context) {
    Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (_) => const RegisterScreen()));
  }
}

// Helper methods for settings
Future<void> _loadAll({
  required ValueNotifier<ThemeMode> themeMode,
  required ValueNotifier<bool> saveLinksHistory,
  required ValueNotifier<String> defaultPlatform,
  required ValueNotifier<bool> showQrByDefault,
  required ValueNotifier<User?> currentUser,
  required Function(bool) setLoading,
}) async {
  try {
    // Load user
    currentUser.value = await AuthService().getCurrentUser();

    // Load preferences
    final prefs = await SharedPreferences.getInstance();

    // Load theme mode
    final themeModeStr = prefs.getString('theme_mode') ?? 'system';
    themeMode.value = _parseThemeMode(themeModeStr);

    // Load other settings
    saveLinksHistory.value = prefs.getBool('save_links_history') ?? true;
    defaultPlatform.value = prefs.getString('default_platform') ?? 'whatsapp';
    showQrByDefault.value = prefs.getBool('show_qr_by_default') ?? false;

    setLoading(false);
  } catch (e) {
    setLoading(false);
    print('Error loading settings: $e');
  }
}

ThemeMode _parseThemeMode(String value) {
  switch (value) {
    case 'light':
      return ThemeMode.light;
    case 'dark':
      return ThemeMode.dark;
    case 'system':
    default:
      return ThemeMode.system;
  }
}

Future<void> _saveThemeMode(ThemeMode mode) async {
  final prefs = await SharedPreferences.getInstance();
  String value;

  switch (mode) {
    case ThemeMode.light:
      value = 'light';
      break;
    case ThemeMode.dark:
      value = 'dark';
      break;
    case ThemeMode.system:
      value = 'system';
      break;
  }

  await prefs.setString('theme_mode', value);
}

Future<void> _saveBoolSetting(String key, bool value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool(key, value);
}

Future<void> _saveStringSetting(String key, String value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString(key, value);
}
