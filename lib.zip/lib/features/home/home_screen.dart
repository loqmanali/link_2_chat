import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:intl_phone_field/phone_number.dart';
import 'package:link_2_chat/widgets/sync_status_widget.dart';

import '../../core/services/sync_service.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/loading_indicator.dart';
import '../../widgets/sync_status_indicator.dart';
import 'components/action_buttons.dart';
import 'components/link_result_card.dart';
import 'components/phone_input_field.dart';
import 'components/qr_code_widget.dart';
import 'home_viewmodel.dart';

class HomeScreen extends HookWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Create the bloc outside of BlocProvider to control its lifecycle
    final homeBloc = useMemoized(() => HomeBloc(), []);
    final focusNode = useFocusNode();

    // Clean up resources when widget is disposed
    useEffect(() {
      return () {
        // Just dispose the focus node, BlocProvider will handle bloc disposal
        focusNode.dispose();
      };
    }, [focusNode]);

    return BlocProvider(
      create: (_) => homeBloc,
      child: BlocBuilder<HomeBloc, HomeState>(
        builder: (context, state) {
          return LoadingOverlay(
            isLoading: state.isLoading,
            child: Scaffold(
              appBar: const CustomAppBar(),
              body: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildHeader(),
                    const SizedBox(height: 24),
                    PhoneInputField(
                      controller: homeBloc.phoneController,
                      focusNode: focusNode,
                      errorText: state.errorMessage,
                      onChanged: (PhoneNumber phoneNumber) {
                        homeBloc.add(PhoneNumberChangedEvent(phoneNumber));
                      },
                    ),
                    const SizedBox(height: 24),
                    ActionButtons(
                      isEnabled: state.isValidNumber,
                      onWhatsAppPressed: () {
                        homeBloc.add(GenerateWhatsAppLinkEvent());
                        focusNode.unfocus();
                      },
                      onTelegramPressed: () {
                        homeBloc.add(GenerateTelegramLinkEvent());
                        focusNode.unfocus();
                      },
                      onQrPressed: () {
                        if (state.generatedLink != null) {
                          homeBloc.add(ShowQrCodeEvent(state.currentPlatform!));
                        } else if (state.isValidNumber) {
                          homeBloc.add(GenerateWhatsAppLinkEvent());
                          homeBloc.add(ShowQrCodeEvent('whatsapp'));
                        }
                        focusNode.unfocus();
                      },
                    ),
                    if (state.generatedLink != null && !state.isShowingQr)
                      LinkResultCard(
                        link: state.generatedLink!,
                        platform: state.currentPlatform!,
                        onQrPressed: () {
                          homeBloc.add(ShowQrCodeEvent(state.currentPlatform!));
                        },
                      ),
                    if (state.isShowingQr && state.generatedLink != null)
                      QrCodeWidget(
                        data: state.generatedLink!,
                        title:
                            '${state.currentPlatform == "whatsapp" ? "WhatsApp" : "Telegram"} QR Code',
                        qrKey: homeBloc.qrKey,
                      ),
                    const SizedBox(height: 24),
                    SyncStatusIndicator(
                      status: SyncStatus(
                        lastSyncTime: DateTime.now(),
                        isOnline: true,
                        message: 'Syncing...',
                      ),
                    ),
                    const SizedBox(height: 24),
                    SyncStatusWidget(),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: 12),
        const Text(
          'Convert Phone Numbers to Chat Links',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
        const Text(
          'Enter a phone number to create instant chat links for WhatsApp and Telegram',
          style: TextStyle(fontSize: 16, color: Colors.grey),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 12),
        const Divider(),
      ],
    );
  }
}
