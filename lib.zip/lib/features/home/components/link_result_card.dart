import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/config/app_theme.dart';
import '../../../core/config/constants.dart';

class LinkResultCard extends StatelessWidget {
  final String link;
  final String platform;
  final VoidCallback onQrPressed;

  const LinkResultCard({
    super.key,
    required this.link,
    required this.platform,
    required this.onQrPressed,
  });

  @override
  Widget build(BuildContext context) {
    final isPlatformWhatsApp = platform == 'whatsapp';
    final platformColor =
        isPlatformWhatsApp ? AppTheme.whatsappColor : AppTheme.telegramColor;
    final platformName = AppConstants.platforms[platform] ?? platform;

    return Container(
      decoration: AppTheme.cardDecoration,
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                isPlatformWhatsApp ? Icons.message : Icons.send,
                color: platformColor,
              ),
              const SizedBox(width: 8),
              Text(
                'Your $platformName Link',
                style: AppTheme.titleStyle.copyWith(color: platformColor),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(4),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    link,
                    style: AppTheme.bodyStyle,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.copy, size: 20),
                  onPressed: () => _copyLink(context),
                  tooltip: 'Copy link',
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton.icon(
                icon: const Icon(Icons.qr_code, size: 20),
                label: const Text('QR'),
                onPressed: onQrPressed,
                style: TextButton.styleFrom(
                  foregroundColor: AppTheme.mediumColor,
                ),
              ),
              const SizedBox(width: 8),
              TextButton.icon(
                icon: const Icon(Icons.share, size: 20),
                label: const Text('Share'),
                onPressed: _shareLink,
                style: TextButton.styleFrom(
                  foregroundColor: AppTheme.mediumColor,
                ),
              ),
              const SizedBox(width: 8),
              TextButton.icon(
                icon: const Icon(Icons.open_in_new, size: 20),
                label: const Text('Open'),
                onPressed: _openLink,
                style: TextButton.styleFrom(foregroundColor: platformColor),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _copyLink(BuildContext context) {
    Clipboard.setData(ClipboardData(text: link));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(AppConstants.copySuccessMessage),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _shareLink() async {
    final platformName = AppConstants.platforms[platform] ?? platform;
    await Share.share(link, subject: '$platformName Link');
  }

  void _openLink() async {
    final uri = Uri.parse(link);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }
}
