import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_field/phone_number.dart';

import '../../../core/config/app_theme.dart';

class PhoneInputField extends StatelessWidget {
  final TextEditingController controller;
  final String? initialCountryCode;
  final Function(PhoneNumber) onChanged;
  final String? errorText;
  final bool enabled;
  final FocusNode? focusNode;

  const PhoneInputField({
    super.key,
    required this.controller,
    this.initialCountryCode,
    required this.onChanged,
    this.errorText,
    this.enabled = true,
    this.focusNode,
  });

  @override
  Widget build(BuildContext context) {
    return IntlPhoneField(
      controller: controller,
      focusNode: focusNode,
      decoration: AppTheme.inputDecoration(
        hintText: 'Enter phone number',
        labelText: 'Phone Number',
      ),
      initialCountryCode: initialCountryCode ?? 'SA',
      invalidNumberMessage: errorText,
      disableLengthCheck: true,
      enabled: enabled,
      onChanged: onChanged,
      dropdownTextStyle: AppTheme.bodyStyle,
      keyboardType: TextInputType.phone,
      flagsButtonPadding: const EdgeInsets.symmetric(horizontal: 8),
    );
  }
}
