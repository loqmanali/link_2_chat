import 'package:flutter/material.dart';

import '../../../core/config/app_theme.dart';

class ActionButtons extends StatelessWidget {
  final VoidCallback onWhatsAppPressed;
  final VoidCallback onTelegramPressed;
  final VoidCallback onQrPressed;
  final bool isEnabled;

  const ActionButtons({
    super.key,
    required this.onWhatsAppPressed,
    required this.onTelegramPressed,
    required this.onQrPressed,
    this.isEnabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                icon: const Icon(Icons.message),
                label: const Text('WhatsApp'),
                onPressed: isEnabled ? onWhatsAppPressed : null,
                style: AppTheme.whatsappButtonStyle,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton.icon(
                icon: const Icon(Icons.send),
                label: const Text('Telegram'),
                onPressed: isEnabled ? onTelegramPressed : null,
                style: AppTheme.telegramButtonStyle,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          icon: const Icon(Icons.qr_code),
          label: const Text('Generate QR Code'),
          onPressed: isEnabled ? onQrPressed : null,
          style: AppTheme.outlineButtonStyle,
        ),
      ],
    );
  }
}
