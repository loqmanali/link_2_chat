import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_hooks/flutter_hooks.dart';

import '../../widgets/app_bar.dart';
import '../../widgets/loading_indicator.dart';
import 'components/recent_activity_list.dart';
import 'components/stats_counter.dart';
import 'components/top_countries_chart.dart';
import 'dashboard_viewmodel.dart';

class DashboardScreen extends HookWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dashboardBloc = useMemoized(() => DashboardBloc(), []);

    // Load data when screen is first shown
    useEffect(() {
      dashboardBloc.add(LoadDashboardDataEvent());
      return () {
        dashboardBloc.close();
      };
    }, [dashboardBloc]);

    return BlocProvider(
      create: (context) => dashboardBloc,
      child: Scaffold(
        appBar: const CustomAppBar(title: 'Dashboard'),
        body: BlocBuilder<DashboardBloc, DashboardState>(
          builder: (context, state) {
            if (state.isLoading && state.recentEntries.isEmpty) {
              return const LoadingIndicator(
                message: 'Loading dashboard data...',
              );
            }

            return RefreshIndicator(
              onRefresh: () async {
                dashboardBloc.add(RefreshDashboardDataEvent());
              },
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildStatCounters(state),
                    const SizedBox(height: 16),
                    TopCountriesChart(countries: state.topCountries),
                    const SizedBox(height: 16),
                    RecentActivityList(entries: state.recentEntries),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildStatCounters(DashboardState state) {
    return Row(
      children: [
        Expanded(
          child: StatsCounter(
            label: 'Total Links',
            count: state.totalLinks,
            icon: Icons.link,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: StatsCounter(
            label: 'WhatsApp',
            count: state.whatsAppLinks,
            icon: Icons.message,
            color: Colors.green,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: StatsCounter(
            label: 'Telegram',
            count: state.telegramLinks,
            icon: Icons.send,
            color: Colors.blue,
          ),
        ),
      ],
    );
  }
}
