import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../core/config/app_theme.dart';
import '../../../core/models/phone_entry.dart';

class RecentActivityList extends StatelessWidget {
  final List<PhoneEntry> entries;

  const RecentActivityList({super.key, required this.entries});

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) {
      return _buildEmptyState();
    }

    return Container(
      decoration: AppTheme.cardDecoration,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Recent Activity', style: AppTheme.titleStyle),
          const SizedBox(height: 16),
          ...entries.map((entry) => _buildActivityItem(entry)),
        ],
      ),
    );
  }

  Widget _buildActivityItem(PhoneEntry entry) {
    final isWhatsApp = entry.platform == 'whatsapp';
    final color = isWhatsApp ? AppTheme.whatsappColor : AppTheme.telegramColor;
    final icon = isWhatsApp ? Icons.message : Icons.send;
    final dateFormat = DateFormat('MMM d, h:mm a');

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  entry.phoneNumber.startsWith('+')
                      ? entry.phoneNumber
                      : '${entry.countryCode} ${entry.phoneNumber}',
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 2),
                Text(
                  entry.countryName.isNotEmpty ? entry.countryName : 'Unknown',
                  style: AppTheme.captionStyle,
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                isWhatsApp ? 'WhatsApp' : 'Telegram',
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w500,
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                dateFormat.format(entry.timestamp),
                style: AppTheme.captionStyle.copyWith(fontSize: 11),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      decoration: AppTheme.cardDecoration,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Recent Activity', style: AppTheme.titleStyle),
          const SizedBox(height: 24),
          SizedBox(
            height: 150,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.history, size: 48, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  Text(
                    'No recent activity',
                    style: TextStyle(color: Colors.grey[600], fontSize: 16),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
