import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../../../core/config/app_theme.dart';

class TopCountriesChart extends StatelessWidget {
  final List<MapEntry<String, int>> countries;
  final bool showLabels;

  const TopCountriesChart({
    super.key,
    required this.countries,
    this.showLabels = true,
  });

  @override
  Widget build(BuildContext context) {
    // If there's no data, show a placeholder
    if (countries.isEmpty) {
      return _buildEmptyState();
    }

    // Colors for the chart sections
    final sectionColors = [
      AppTheme.primaryColor,
      AppTheme.secondaryColor,
      AppTheme.accentColor,
      Colors.purple,
      Colors.teal,
      Colors.pink,
    ];

    // Calculate total for percentages
    final total = countries.fold<int>(0, (sum, item) => sum + item.value);

    // Generate pie chart sections
    final sections = <PieChartSectionData>[];

    for (int i = 0; i < countries.length; i++) {
      final item = countries[i];
      final percentage = total > 0 ? (item.value / total) * 100 : 0;

      sections.add(
        PieChartSectionData(
          color: sectionColors[i % sectionColors.length],
          value: item.value.toDouble(),
          title: showLabels ? '${percentage.toStringAsFixed(1)}%' : '',
          radius: 50,
          titleStyle: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      );
    }

    return Container(
      decoration: AppTheme.cardDecoration,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Top Countries', style: AppTheme.titleStyle),
          const SizedBox(height: 16),
          SizedBox(
            height: 200,
            child: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: PieChart(
                    PieChartData(
                      sections: sections,
                      centerSpaceRadius: 30,
                      sectionsSpace: 2,
                      borderData: FlBorderData(show: false),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(flex: 2, child: _buildLegend(sectionColors)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegend(List<Color> colors) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children:
          countries.asMap().entries.map((entry) {
            final index = entry.key;
            final item = entry.value;

            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: colors[index % colors.length],
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      item.key,
                      overflow: TextOverflow.ellipsis,
                      style: AppTheme.captionStyle,
                    ),
                  ),
                  Text(
                    item.value.toString(),
                    style: AppTheme.captionStyle.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      decoration: AppTheme.cardDecoration,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Top Countries', style: AppTheme.titleStyle),
          const SizedBox(height: 24),
          SizedBox(
            height: 150,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.public, size: 48, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  Text(
                    'No data available yet',
                    style: TextStyle(color: Colors.grey[600], fontSize: 16),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
